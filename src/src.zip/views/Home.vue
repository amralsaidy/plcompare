<template>
    <div class="wrapper">
        <h1 class="deepshadow">Programming languages Comparison<> </h1>
        <div class="container container-1">
            <div class="row">
                <h6 class="col-md-3 label-1">Choose Comparison Languages :</h6>
                <div class="col-md-9 langs-container">
                    <ul class="chbx-container">
                        <li><input type="checkbox" id="chbx1" value="Rainbow Dash"><label for="chbx1">C</label></li>
                        <li><input type="checkbox" id="chbx2" value="C++" checked><label for="chbx2">C++</label></li>
                        <li><input type="checkbox" id="chbx3" value="C#" checked><label for="chbx3">C#</label></li>
                        <li><input type="checkbox" id="chbx4" value="Java"><label for="chbx4">Java</label></li>
                        <li><input type="checkbox" id="chbx5" value="Kotlin"><label for="chbx5">Kotlin</label></li>
                        <li><input type="checkbox" id="chbx6" value="Python" checked><label for="chbx6">Python</label>
                        </li>
                        <li><input type="checkbox" id="chbx7" value="JavaScript"><label for="chbx7">JavaScript</label>
                        </li>
                        <li><input type="checkbox" id="chbx8" value="PHP"><label for="chbx8">PHP</label></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container container-2">
            <div class="row">
                <h6 class="col-md-3 label-1">Select Comparison Content :</h6>
                <div class="col-md-9 custom-dropdown">
                    <select>
                        <option>Sherlock Holmes</option>
                        <option>The Great Gatsby</option>
                        <option>V for Vendetta</option>
                        <option>The Wolf of Wallstreet</option>
                        <option>Quantum of Solace</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="container container-3">
            <div class="row">
                <div class="col-md-12 main">
                    <div class="btn-container">
                        <a href="#" class="btn">Compare</a>
                    </div>
                    <div class="view">
                <pre><code class="javascript">
$(document).ready(function() {
  $('pre code').each(function(i, block) {
    hljs.highlightBlock(block);
  });
});
</code></pre>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Home"
    }
</script>

<style scoped>

</style>